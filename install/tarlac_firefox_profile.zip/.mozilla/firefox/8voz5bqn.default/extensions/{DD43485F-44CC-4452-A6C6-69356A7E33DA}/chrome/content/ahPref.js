var Cc = Components.classes;
var Ci = Components.interfaces;

var pref = Cc['@mozilla.org/preferences-service;1']
           .getService(Ci.nsIPrefService).getBranch('extensions.autohide.');

var aWin = Cc['@mozilla.org/appshell/window-mediator;1']
           .getService().QueryInterface(Ci.nsIWindowMediator)
           .getMostRecentWindow('navigator:browser');

var TBC, d=document, dE, nC, nCa, boxes, nClabel, k, winUtil=false;

function initPref() {
  dE = d.documentElement

  if (!aWin) {
    alert(dE.getAttribute('aherror'))
    dE.cancelDialog()
    return false
  }

  if ('@krickelkrackel/ahWin32Utils;1' in Cc)
    winUtil = Cc['@krickelkrackel/ahWin32Utils;1'].createInstance(Ci.ahIWin32Utils);

  TBC = aWin.document.getElementById('navigator-toolbox').childNodes
  return true
}

function savePrefs() {
  pref.deleteBranch('bars.')

  for (k=0; k < boxes.length; k++)
    pref.setBoolPref(boxes[k].id, boxes[k].checked);

  return true
}

function getCTB() {
  for (k=0; k < TBC.length; k++) {
    if (TBC[k].localName && (TBC[k].localName == 'toolbar' || TBC[k].localName == 'menubar')) {
      var row = d.createElement('row')
      nC = d.createElement('checkbox')
      nC.id = 'bars.' + TBC[k].id
      nClabel = ''

      if (TBC[k].hasAttribute('toolbarname'))
        nClabel = TBC[k].getAttribute('toolbarname');
      else if (TBC[k].hasAttribute('grippytooltiptext'))
        nClabel = TBC[k].getAttribute('grippytooltiptext');
      else {
        if (TBC[k].id == 'toolbar-menubar')
          nClabel = dE.getAttribute('ahmenu');
        if (nClabel == '')
          nClabel = TBC[k].id.slice(0,1).toUpperCase() + TBC[k].id.substring(1, TBC[k].id.length).toLowerCase();
      }
      nC.setAttribute('label', nClabel)
      row.appendChild(nC)
      var box = d.createElement('hbox')
      var spa = d.createElement('spacer')
      spa.setAttribute("flex", 1)
      box.appendChild(spa)
      nC = d.createElement('checkbox')
      nC.id = 'bars.' + TBC[k].id + '.always'
      box.appendChild(nC)
      box.appendChild(spa.cloneNode(true))
      row.appendChild(box)
      d.getElementById('ahBars').insertBefore(row, d.getElementById('tabRow'))
    }
  }

  boxes = d.getElementsByTagName('checkbox')

  d.getElementById('bars.statBar.always').addEventListener('CheckboxStateChange',
    function() {boxes[0].disabled = this.checked}, true);

  for (k=0; k < boxes.length; k++) {
    try {
      boxes[k].checked = pref.getBoolPref(boxes[k].id)
    }
    catch (e) {}
  }

  if (winUtil && winUtil.supports('systemTaskBar'))
    d.getElementById('semiMode').disabled = winUtil.isAutoHidden() ? true : false;
  else
    d.getElementById('winTaskRow').hidden = true;
}