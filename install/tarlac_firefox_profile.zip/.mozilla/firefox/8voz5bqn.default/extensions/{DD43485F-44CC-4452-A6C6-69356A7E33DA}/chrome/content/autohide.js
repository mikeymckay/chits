var autoHIDE = {
  CI     : Components.interfaces,

  pref   : Components.classes["@mozilla.org/preferences-service;1"]
           .getService(Components.interfaces.nsIPrefService)
           .getBranch("extensions.autohide."),

  winMed : Components.classes["@mozilla.org/appshell/window-mediator;1"]
           .getService().QueryInterface(Components.interfaces.nsIWindowMediator),

  obs    : Components.classes["@mozilla.org/observer-service;1"]
           .getService(Components.interfaces.nsIObserverService),

  drag   : Components.classes["@mozilla.org/widget/dragservice;1"]
           .getService(Components.interfaces.nsIDragService),

  zombie : false,
  init   : false,

  GetBoolPref : function(v) {
    try {
      return this.pref.getBoolPref(v)
    }
    catch (e) {
      return false
    }
  },

  MouseObserver : {
    observe : function (subject, topic, data) {
      if (!autoHIDE.winUtil.isActiveWindow())
        return;

      if (topic == "ahMouseMove") {
        var mData = data.split("|");

        if (!autoHIDE.topVis && autoHIDE.winUtil.isShiftDown && autoHIDE.zombie && autoHIDE.zombieMove) {
          window.moveTo(mData[0]-100, mData[1]-100)
          return
        }

        var evt = document.createEvent("MouseEvents");
        evt.initMouseEvent("mousemove", 1, 1, window, 0,
                           mData[0], mData[1], 0, 0, 0, 0, 0, 0, 0, window);

        autoHIDE.Listener_MouseMove(evt);
      }
    }
  },

  ProgressListener : {
    WPL : Components.interfaces.nsIWebProgressListener,

    QueryInterface : function(ID) {
      if (ID.equals(this.WPL))
        return this;

      return Components.results.NS_NOINTERFACE;
    },

    onStateChange : function(a, b, ahF, c) {
      var ah = autoHIDE

      if (ah.GetBoolPref("statFloat") && !ah.GetBoolPref("bars.statBar.always") && !ah.bottomVis) {
        if (ahF & this.WPL.STATE_START)
          ah.statBar.setAttribute("ahHIDE", false);

        if (ahF & this.WPL.STATE_STOP)
          ah.statBar.setAttribute("ahHIDE", true);
      }

      try {
        document.getElementById("autoHideToolTip").hidePopup();
      }
      catch (e) {}
    },

    onLocationChange : function() {
      if (autoHIDE.topVis)
        autoHIDE.MoveContent(true);

      if (autoHIDE.GetBoolPref("toolTipUrl"))
        getBrowser().mCurrentBrowser.setAttribute("tooltip", "autoHideToolTip");
    },

    onProgressChange : function(){},
    onStatusChange : function(){},
    onSecurityChange : function(){},
    onLinkIconAvailable : function(){}
  },

  GetCMDLine : function() {
    if (this.init)
      return;

    var ah = autoHIDE
    ah.init = true
    ah.mainWin = document.getElementById("main-window")
    ah.mainWinPersist = ah.mainWin.getAttribute("persist")
    ah.BC = document.getElementById("autoHIDE_BC")

    document.getElementById("contentAreaContextMenu")
            .addEventListener("popupshowing", function(e){autoHIDE.Listener_Context(e)}, true);

    addEventListener("unload", function() {
      var ah = autoHIDE
      ah.pref.setBoolPref("openFull", fullScreen)
      ah.pref.setBoolPref("openZombie", ah.zombie)

      if (fullScreen || ah.zombie) {
        if (ah.winState == STATE_MAXIMIZED) {
          ah.mainWin.setAttribute("persist", ah.mainWinPersist)
          ah.mainWin.setAttribute("sizemode", "maximized")
        }
      }

      try {
        ah.obs.removeObserver(ah.MouseObserver, "ahMouseMove")
      }
      catch (e) {}
      getBrowser().removeProgressListener(ah.ProgressListener)
    }, false);

    ah.Enum = ah.winMed.getEnumerator("navigator:browser")
    ah.Enum.getNext()

    if (!ah.Enum.hasMoreElements()) {
      ah.openFull = ah.GetBoolPref("openFull")
      ah.openZombie = ah.GetBoolPref("openZombie")
    }
    else if ("arguments" in window && ah.GetBoolPref("newFull")) {
      if (window.opener)
        ah.lastWin = window.opener;
      else {
        ah.Enum1 = ah.winMed.getZOrderDOMWindowEnumerator("navigator:browser", true)
        ah.Enum1.getNext()
        ah.lastWin = ah.Enum1.getNext()
      }
      if (ah.lastWin && ah.lastWin.fullScreen)
        ah.openFull = true;

      if (ah.lastWin && ah.lastWin.autoHIDE && ah.lastWin.autoHIDE.zombie)
        ah.openZombie = true;
    }

    var timeout = 500;

    if ("@krickelkrackel/ahWin32Utils;1" in Components.classes) {
      try {
        ah.winUtil = Components.classes["@krickelkrackel/ahWin32Utils;1"]
                     .createInstance(ah.CI.ahIWin32Utils);

        ah.baseWin = window.QueryInterface(ah.CI.nsIInterfaceRequestor)
                    .getInterface(ah.CI.nsIWebNavigation)
                    .QueryInterface(ah.CI.nsIBaseWindow);

        ah.winUtil.init(ah.baseWin);
        timeout = ah.winUtil.getTimeout;
      }
      catch (e) {
        ah.winUtil = false;
      }
    }

    if (ah.openFull || ah.openZombie)
      setTimeout("fullScreen=true", timeout);
  },

  ToggleBottom : function() {
    var ah = autoHIDE

    if (ah.GetBoolPref("bars.statBar.always") || !ah.GetBoolPref("bars.statBar"))
      return;

    ah.noRes = true
    ah.statBar.setAttribute("ahHIDE", ah.bottomVis)
    ah.bottomVis = !ah.bottomVis
  },

  ToggleTop : function(toolBars) {
    var ah = autoHIDE

    if (!ah.noFloat && ah.winUtil)
      ah.noRes = true

    if (ah.topVis) {
      if (ah.noFloat || !ah.winUtil)
        ah.ResetMenu();
      else {
        ah.winUtil.setRedraw(false, false)
        ah.ResetMenu()
        ah.MoveContent(false)
        setTimeout(autoHIDE.winUtil.setRedraw, 0, true, false)
      }

      return
    }

    if (!ah.noFloat && ah.winUtil)
      ah.winUtil.setRedraw(false, false);

    ah.delta = getBrowser().mCurrentBrowser.boxObject.y
    ah.SetMenu(toolBars)
    ah.delta = getBrowser().mCurrentBrowser.boxObject.y - ah.delta

    if (ah.noFloat || !ah.winUtil) {
      ah.delta = 0
      return
    }

    try {
      document.getElementById("bookmarksBarContent").updateChevron(null);
    }
    catch (e) {}

    ah.MoveContent(true)
    setTimeout(autoHIDE.winUtil.setRedraw, 0, true, false)
  },

  MoveContent : function(aMove) {
    var ah = autoHIDE

    if (!ah.noFloat && ah.winUtil) {
      if (aMove) {
        var cB = getBrowser().mCurrentBrowser;

        if (!cB.ahMargin) {
          if (!cB.style.marginTop)
           cB.ahOldTop = 0;
          else
            cB.ahOldTop = parseFloat(cB.style.marginTop);

          cB.style.marginTop = cB.ahOldTop - ah.delta  + "px"
          cB.ahMargin = true
        }
        return
      }

      var brs = getBrowser().browsers

      for (var b = 0; b < brs.length; b++) {
        if (brs[b].ahMargin) {
          brs[b].style.marginTop = brs[b].ahOldTop + "px"
          brs[b].ahMargin = null
        }
      }
    }
  },

  SetMenu : function(toolBars) {
    var ah = autoHIDE
    ah.Nav.setAttribute("ahHIDE", false)

    for (x=0; x < ah.NavC.length; x++) {
      if (ah.GetBoolPref("bars." + ah.NavC[x].id + ".always") ||
          (toolBars  && (ah.NavC[x].id in toolBars))) {
        ah.NavC[x].setAttribute("ahHIDE", false)
        continue
      }
      ah.NavC[x].setAttribute("ahHIDE", !ah.GetBoolPref("bars." + ah.NavC[x].id));
    }

    if (ah.CheckTabAutoHide())
      ah.tabBar.setAttribute("ahHIDE", true);
    else
      ah.tabBar.setAttribute("ahHIDE", (!ah.GetBoolPref("bars.tabBar") && !ah.GetBoolPref("bars.tabBar.always")) ? true : false)

    ah.topVis = true
  },

  ResetMenu : function(aBool) {
    var ah = autoHIDE
    ah.Nav.setAttribute("ahHIDE", true)
    ah.NavC = ah.Nav.childNodes

    for (x=0; x < ah.NavC.length; x++) {
      if (ah.GetBoolPref("bars." + ah.NavC[x].id + ".always")) {
        ah.Nav.setAttribute("ahHIDE", false)
        ah.NavC[x].setAttribute("ahHIDE", false)
        continue
      }
      ah.NavC[x].setAttribute("ahHIDE", true)
    }

    if (ah.CheckTabAutoHide())
      ah.tabBar.setAttribute("ahHIDE", true);
    else
      ah.tabBar.setAttribute("ahHIDE", (ah.GetBoolPref("bars.tabBar.always")) ? false : true);

    ah.topVis = false

    if (aBool && ah.winUtil)
      ah.winUtil.goFull(true, ah.GetBoolPref("semiMode"), false, ah.zombie);
  },

  InitHide : function(e) {
    var ah = autoHIDE
    autoHIDE_ToolTip.setToolTip()

    if (!fullScreen && !ah.zombie) {
      ah.Nav = document.getElementById("navigator-toolbox")
      ah.NavC = ah.Nav.childNodes

      for (x=0; x < ah.NavC.length; x++) {
        if (ah.NavC[x].localName.toLowerCase() != "toolbar")
          continue;

        ah.NavC[x].setAttribute("fullscreentoolbar", (ah.GetBoolPref("keepButtons")) ? false : true)
      }

      ah.winState = window.windowState
      ah.mainWin.setAttribute("persist", ah.mainWinPersist)

      if (ah.winUtil && (ah.GetBoolPref("zombieMode") || ah.winUtil.isShiftDown || ah.openZombie)) {
        var makeZombie = (ah.pref.getIntPref("zombieBorder") < 2 && window.windowState == STATE_MAXIMIZED) ? false : true

        if (makeZombie) {
          ah.zombie = true
          ah.zombieMove = (ah.pref.getIntPref("zombieBorder") < 2 && ah.GetBoolPref("zombieMove")) ? true : false
          e.preventDefault()
          e.stopPropagation()
        }
      }
      else
        ah.mainWin.removeAttribute("persist");

      ah.openZombie = ah.bottomVis = false
      ah.senseArea = ah.pref.getIntPref("senseArea")
      ah.senseArea = ah.zombie ? ah.senseArea+3 : ah.senseArea+0
      ah.tabBar = getBrowser().mStrip
      ah.statBar = document.getElementById("status-bar")
      ah.statBar.setAttribute("ahZOMBIE", ah.zombie)
      ah.statBar.setAttribute("ahHIDE", !ah.GetBoolPref("bars.statBar.always"))
      ah.delay = ah.pref.getIntPref("delay")
      ah.hideDelay = ah.pref.getIntPref("hideDelay")
      ah.noFloat = ah.GetBoolPref("noFloat")
      getBrowser().addProgressListener(ah.ProgressListener, ah.CI.nsIWebProgress.NOTIFY_ALL)

      if (ah.winUtil)
        ah.obs.addObserver(ah.MouseObserver, "ahMouseMove", false);
      else
        addEventListener("mousemove", ah.Listener_MouseMove, true);

      addEventListener("popupshown", ah.Listener_Popup, false)
      addEventListener("popuphidden", ah.Listener_Popup, false)
      addEventListener("keypress", ah.Listener_Input, true)
      ah.Nav.addEventListener("DOMAttrModified", ah.Listener_Menu, true)
      addEventListener("resize", ah.Listener_Resize, true)
      ah.tabBar.addEventListener("DOMNodeInserted", ah.Listener_Tabs, false)
      ah.tabBar.addEventListener("DOMNodeRemoved", ah.Listener_Tabs, false)

      if (!ah.commandsChanged) {
        ah.ChangeCommand(["Browser:OpenLocation", "cmd_newNavigatorTab", "focusURLBar"],
                          "if (fullScreen || autoHIDE.zombie) autoHIDE.Listener_Location('urlbar'); ");

        ah.ChangeCommand(["Tools:Search"],
                          "if (fullScreen || autoHIDE.zombie) autoHIDE.Listener_Location('search-container'); ");

        ah.commandsChanged = true;
      }

      ah.BC.setAttribute("checked", true)
      ah.Popup = null
      return
    }

    if (ah.zombie) {
      e.preventDefault()
      e.stopPropagation()
      ah.zombie = false
    }

    ah.BC.setAttribute("checked", false)

    try {
      ah.obs.removeObserver(ah.MouseObserver, "ahMouseMove")
    }
    catch (e) {}

    if (ah.winUtil && !ah.noFloat && ah.topVis)
      ah.MoveContent(false);

    getBrowser().removeProgressListener(ah.ProgressListener)
    removeEventListener("resize", ah.Listener_Resize, true)
    removeEventListener("popupshown", ah.Listener_Popup, false)
    removeEventListener("popuphidden", ah.Listener_Popup, false)
    removeEventListener("mousemove", ah.Listener_MouseMove, true)
    removeEventListener("keypress", ah.Listener_Input, true)
    ah.Nav.removeEventListener("DOMAttrModified", ah.Listener_Menu, true)
    ah.tabBar.removeEventListener("DOMNodeInserted", ah.Listener_Tabs, false)
    ah.tabBar.removeEventListener("DOMNodeRemoved", ah.Listener_Tabs, false)

    setTimeout(function () {
      if (ah.winUtil)
        ah.winUtil.goFull(false, false, false, false);

      while (document.getElementsByAttribute("ahHIDE", "*").length)
        document.getElementsByAttribute("ahHIDE", "*")[0].removeAttribute("ahHIDE");

      ah.tabBar.removeAttribute("ahHIDE");
      ah.mainWin.setAttribute("persist", ah.mainWinPersist);
    }, 0)
  },

  ChangeCommand : function(items, text) {
    for (x = 0; x < items.length; x++) {
      var item = document.getElementById(items[x])
      if (item)
        item.setAttribute("oncommand", text + item.getAttribute("oncommand"));
    }
  },

  CheckTabAutoHide : function(aBool) {
    var tabsAutoHide = getBrowser().mPrefs.getBoolPref("browser.tabs.autoHide")
    var tabCount = getBrowser().mTabs.length

    if (tabCount == 1 && tabsAutoHide)
      return true;

    return false;
  },

  Listener_Tabs : function(e) {
    if (getBrowser().mTabs.length > 2 || e.originalTarget.localName != "tab")
      return;

    setTimeout(autoHIDE.HandleTabs, 0)
  },

  HandleTabs : function() {
    var ah = autoHIDE

    if (ah.topVis) {
      var toolbars = new Array()

      for (x=0; x < ah.NavC.length; x++) {
        if (ah.NavC[x].getAttribute("ahHIDE") == "false")
          toolbars[ah.NavC[x].id] = true;
      }

      ah.ToggleTop()
      ah.ToggleTop(toolbars)
    }
    else if (ah.GetBoolPref("bars.tabBar.always"))
      ah.tabBar.setAttribute("ahHIDE", ah.CheckTabAutoHide());
  },

  ForceTopVis : function(aNode, isTab, isRemoved) {
    var ah = autoHIDE

    while (aNode != null && aNode != ah.Nav) {
      if (aNode.localName == "toolbar") {
        if (aNode.getAttribute("ahHIDE") == "true") {
          var toolbars = new Array();
          toolbars[aNode.id] = true;

          for (x=0; x < ah.NavC.length; x++) {
            if (ah.NavC[x].getAttribute("ahHIDE") == "false")
              toolbars[ah.NavC[x].id] = true;
          }

          if (ah.topVis)
            ah.ToggleTop();

          ah.ToggleTop(toolbars)
        }

        break
      }

      aNode = aNode.parentNode
    }
  },

  Listener_Context : function(e) {
    if (e.target.id != "contentAreaContextMenu")
      return;

    var cMenu = document.getElementById("context-toggle-fullscreen")
    cMenu.hidden = cMenu.previousSibling.hidden = true

    if ((!document.getElementById("context-back").hasAttribute("hidden") ||
         !document.getElementById("context-viewimage").hasAttribute("hidden")) &&
         !this.GetBoolPref("noContext"))
      cMenu.hidden = cMenu.previousSibling.hidden = false;
  },

  Listener_Menu : function(e) {
    if (!autoHIDE.Popup && e.attrName == '_moz-menuactive' && e.newValue == "true")
      autoHIDE.ForceTopVis(e.target);
  },

  Listener_Input : function(e) {
    if (autoHIDE.topVis && e.keyCode == 13) {
      autoHIDE.ToggleTop()
      return
    }

    if (e.keyCode == e.DOM_VK_F6)
      autoHIDE.ForceTopVis(gURLBar);
  },

  Listener_Location : function(target) {
    if (document.getElementById(target))
      autoHIDE.ForceTopVis(document.getElementById(target));
  },

  Listener_MouseMove : function(e) {
    var ah = autoHIDE

    if (ah.Popup && ah.Popup.state && ah.Popup.state == "closed")
      ah.Popup = null;

    if (ah.Popup || ("gestureInProgress" in window && gestureInProgress))
      return;

    if (ah.timerTop)
      clearTimeout(ah.timerTop);

    if (!ah.topVis && e.screenY <= ah.mainWin.boxObject.screenY + ah.senseArea) {
      if (!ah.drag.getCurrentSession())
        ah.timerTop = setTimeout("autoHIDE.ToggleTop()", ah.delay);
      else
        ah.ToggleTop();
    }

    if (ah.topVis && e.screenY > (getBrowser().mCurrentBrowser.boxObject.screenY + ah.delta + 50)) {
      if (!ah.drag.getCurrentSession())
        ah.timerTop = setTimeout("autoHIDE.ToggleTop()", ah.hideDelay);
      else
        ah.ToggleTop();
    }

    if (ah.timerBottom)
      clearTimeout(ah.timerBottom);

    if (!ah.bottomVis && e.screenY > ah.statBar.boxObject.screenY - ah.senseArea -2)
      ah.timerBottom = setTimeout("autoHIDE.ToggleBottom()", ah.delay);

    if (ah.bottomVis && e.screenY < ah.statBar.boxObject.screenY -50)
      ah.timerBottom = setTimeout("autoHIDE.ToggleBottom()", ah.hideDelay);
  },

  Listener_Popup : function(e) {
    var aNode = e.originalTarget
    var ah = autoHIDE

    if (aNode.nodeName != "tooltip") {
      if (e.type == "popupshown" && !ah.Popup)
        ah.Popup = aNode;

      if (e.type == "popuphidden" && aNode == ah.Popup)
        ah.Popup = null;
    }
  },

  Listener_Resize : function(e) {
    if (autoHIDE.noRes) {
      try {
        e.preventDefault()
        e.stopPropagation()
        setTimeout("autoHIDE.noRes = false", 0)
      }
      catch (e) {}

      autoHIDE.noRes = false
    }
  }
}

// == Link-Tooltip ==

var autoHIDE_ToolTip = {
  CI   : Components.interfaces,
  node : null,
  row  : new Array(),

  setToolTip : function() {
    if (!fullScreen && !autoHIDE.zombie) {
      if (autoHIDE.GetBoolPref("toolTipUrl")) {
        for (x = 0; x < getBrowser().browsers.length; x++)
          getBrowser().browsers[x].setAttribute("tooltip", "autoHideToolTip");
      }
    }
    else {
      for (x = 0; x < getBrowser().browsers.length; x++)
        getBrowser().browsers[x].setAttribute("tooltip", "aHTMLTooltip");
    }
  },

  fillToolTip : function() {
    if (("gestureInProgress" in window) && gestureInProgress)
      return false;

    this.row = [document.getElementById("autoHide1row"),
                document.getElementById("autoHide2Row"),
                document.getElementById("autoHide3row")]

    this.row[0].hidden = this.row[1].hidden = this.row[2].hidden = true
    this.row[0].textContent = this.row[2].value = null
    this.node = document.tooltipNode
    this.show = false

    if (!this.node || !this.node.ownerDocument.defaultView ||
        this.node.namespaceURI == "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul")
      return false;

    for (this.node; this.node; this.node = this.node.parentNode) {
      if (!this.row[2].value) {
        if ((this.node instanceof this.CI.nsIDOMHTMLAnchorElement ||
             this.node instanceof this.CI.nsIDOMHTMLAreaElement ||
             this.node instanceof this.CI.nsIDOMHTMLLinkElement) && this.node.href != "")
          this.row[2].value = document.getElementById("statusbar-display").getAttribute("label");
      }

      if (!this.row[0].textContent) {
        try {
          if (("hasAttribute" in this.node) && this.node.hasAttribute("title"))
            this.row[0].textContent = this.node.getAttribute("title");
        }
        catch (e) {}
      }

      if (this.row[0].textContent && this.row[2].value)
        break;
    }

    for (var x = 0; x < this.row.length; x++) {
      if (this.row[x].textContent || this.row[x].value) {
        this.row[x].hidden = false
        this.show = true
      }
    }

    if (this.show) {
      if (!this.row[0].hidden && !this.row[2].hidden)
        this.row[1].hidden = false;

      document.getElementById("autoHideToolTip").setAttribute("noautohide", (this.row[2].hidden) ? false : true);
    }

    return this.show;
  }
}

// == Overrides ==

function onFullScreen(e) {
  var ah = autoHIDE

  if (!fullScreen && !ah.zombie) {
    ah.InitHide(e)
    FullScreen.showXULChrome("toolbar", false)

    if (ah.winUtil)
      ah.winUtil.getWindowCoords();

    if (ah.GetBoolPref("semiMode"))
      setTimeout("autoHIDE.ResetMenu(true)", 0);
    else
      ah.ResetMenu(true);

    return
  }

  if (fullScreen || ah.zombie) {
    ah.InitHide(e)
    FullScreen.showXULChrome("toolbar", true)
  }
}

addEventListener("load", function(){autoHIDE.GetCMDLine()}, false)