pref("extensions.tryagain.timeout", 10);
pref("extensions.tryagain.repeat", 50);
pref("extensions.tryagain.showmenu", 0);
